const EditEventModal = () => {
  return (
    <div className="fixed top-0 left-0 w-full h-full bg-white">
      Edit
    </div>
  )
}

export default EditEventModal