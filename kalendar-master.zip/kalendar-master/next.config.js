module.exports = {
  reactStrictMode: true,
  images: {
    domains: ['gravatar.com', 'www.gstatic.com']
  }
}
